/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo03;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

/**
 * Ejemplo que ilustra como conectar 
 * @author salva
 */
public class Ejemplo03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        File propertiesFile=new File("./jpa.properties");
        Properties propiedades=new Properties();
        
        //Intentamos leer el archivo el archivo jpa.properties
        try(InputStream is=new FileInputStream(propertiesFile)) {
            propiedades.load(is);
        } catch (FileNotFoundException ex) {
            System.out.println("No encontrado el archivo jpa.properties");
        } catch (IOException ex) {
            System.out.println("Error al leer el archivo jpa.properties");
        } finally {
            if (propiedades.isEmpty()) {
                System.out.println("Usando configuraci�n por defecto:");
                /* driver utilizado en esta conexi�n */
                propiedades.put("javax.persistence.jdbc.driver", "org.h2.Driver");
                /* URL para conectar a la base de datos*/
                propiedades.put("javax.persistence.jdbc.url", "jdbc:h2:./mibasededatos.h2db");
                /* nombre de usuario para conectar */
                propiedades.put("javax.persistence.jdbc.user", "");
                /* password para necesario para conectar */
                propiedades.put("javax.persistence.jdbc.password", "");
                /* modelo de generaci�n de base de datos */
                propiedades.put("javax.persistence.schema-generation.database.action", "create");
            }
        }
        
        
        try {
                                     
            EntityManagerFactory emf=Persistence.createEntityManagerFactory("EjemplosJPA",propiedades);
            EntityManager em=emf.createEntityManager();
            
            if (em.isOpen())
            {
                System.out.println("EntityManager con conexi�n abierta.");
            }
            else
            {
                System.out.println("EntityManager sin conexi�n.");
            }
            
            em.close();
            emf.close();
        } catch (PersistenceException pe) {
            System.err.println("Error al conectar con la base de datos.");
        }
    }
    
}
